#include <opencv2/opencv.hpp>
#include <iostream>

#include "../../src/Api_CentringCable.hpp"
#include "../../src/centringCableParam.h"

using namespace std;
using namespace cv;
//test
int main()
{
    APICentringCable api;
    
    Mat imgSrc[3];
    
    string leftDown = "E:/cable/getedge/camera3_1/left_down/1 (";
    string leftUp = "E:/cable/getedge/camera3_1/left_up/1 (";
    string rightUp = "E:/cable/getedge/camera3_1/right_up/1 (";

    //ofstream out("line.txt");
    MoveInfo moveInfo;
    MoveStatus moveStatus;

    api.api_loadMoveData("moveData.txt", moveStatus);
    int direct;
    double moveValue;
    int i = 1068;
    int n = 0;
    int step = 0;

    Mat calibImg[9];
    for (int n = i; n < i + 3; n++)
    {
        calibImg[(n - i) * 3] = imread(leftUp + to_string(n) + ").jpg", 0);
        calibImg[(n - i) * 3 + 1] = imread(leftDown + to_string(n) + ").jpg", 0);
        calibImg[(n - i) * 3 + 2] = imread(rightUp + to_string(n) + ").jpg", 0);
    }

    api.api_cableStatus(calibImg, 3, 3, moveInfo, moveStatus);
    if (moveStatus.direct == CABLE_DIRECT_STATUS_UP)         step = -1;
    else if (moveStatus.direct == CABLE_DIRECT_STATUS_DOWN)  step = 1;
    else if (moveStatus.direct == CABLE_DIRECT_STATUS_OK)
    {
        cout << "optimal pos:" << i << endl;
    }

    while (1 & moveStatus.direct != CABLE_DIRECT_STATUS_OK)
    {
        imgSrc[0] = imread(leftUp + to_string(i) + ").jpg", 0);
        imgSrc[1] = imread(leftDown + to_string(i) + ").jpg", 0);
        imgSrc[2] = imread(rightUp + to_string(i) + ").jpg", 0);

        if (n < 30)
        {
            api.api_optimalMove(imgSrc, moveInfo, moveValue);
        }
        else
        {
            n = 0;
            api.api_optimalMove(imgSrc, moveInfo, moveValue, false);

            if (moveValue < 0)
            {
                cout << "optimal pos:" << i + moveValue * step << endl;
                break;
            }
        }
        n++;
        i += step;
        //out<<xMean[0]<<","<<xMean[1]<<","<<xMean[2]<<std::endl;
    }
    //out.close();

    //��ʱ������
    return 0;
}

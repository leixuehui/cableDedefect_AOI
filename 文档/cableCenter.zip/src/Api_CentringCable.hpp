#pragma once
#include <opencv2/opencv.hpp>
#include "centringCableParam.h"

using namespace std;
using namespace cv;

#define CENTRINGCABLE_EXPORTS

#ifdef CENTRINGCABLE_EXPORTS
#define CENTRINGCABLEDLL_API __declspec(dllexport)
#else
#define CENTRINGCABLEDLL_API __declspec(dllimport)
#endif // CENTRINGCABLE_EXPORTS

class CENTRINGCABLEDLL_API APICentringCable
{
public:
    APICentringCable();
    ~APICentringCable();
    
    int api_init();
    int api_loadMoveData(string filePath, MoveStatus &moveStatus);
    int api_cableStatus(Mat *img, int nCamera, int nFrame, MoveInfo &outMoveInfo, MoveStatus &outMoveStatus);
    int api_optimalMove(Mat *img, MoveInfo &moveInfo, double &moveValue, bool isMoving = true);
private:
    void *gProcess = nullptr;
};
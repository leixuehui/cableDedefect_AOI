#include "Api_CentringCable.hpp"

#include "centringCable.h"
APICentringCable::APICentringCable()
{
    if(!gProcess)   gProcess = new CentringCable();
}

APICentringCable::~APICentringCable()
{
}

int APICentringCable::api_init()
{
    if (!gProcess)   gProcess = new CentringCable();
    return 0;
}

int APICentringCable::api_loadMoveData(string filePath, MoveStatus & moveStatus)
{
    int err = 0;
    if (!gProcess)  return -1;

    CentringCable *process = (CentringCable*)gProcess;
    err = process->loadMoveData(filePath, moveStatus);
    
    return err;
}

int APICentringCable::api_cableStatus(Mat * img, int nCamera, int nFrame, MoveInfo & outMoveInfo, MoveStatus & outMoveStatus)
{
    int err = 0;
    if (!gProcess)  return -1;

    CentringCable *process = (CentringCable*)gProcess;
    err = process->cableStatus(img, nCamera, nFrame, outMoveInfo, outMoveStatus);

    return err;
}

int APICentringCable::api_optimalMove(Mat * img, MoveInfo & moveInfo, double & moveValue, bool isMoving)
{
    int err = 0;
    if (!gProcess)  return -1;

    CentringCable *process = (CentringCable*)gProcess;
    err = process->optimalMove(img, moveInfo, moveValue, isMoving);
    return err;
}
